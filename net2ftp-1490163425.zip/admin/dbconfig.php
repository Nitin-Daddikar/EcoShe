<?php

$con = mysqli_connect("mysql.hostinger.in" , "u464516702_root" , "Kronosold93" , "u464516702_ecosh");
//mysql_select_db($datbase);
?>